# MERN Autoship Starter (Mocked Carrier Integrations)

This scaffold provides a working MERN-style starter for the Shopify Auto-Shipping system described.

It includes:
- backend/ - Express + Mongoose server that accepts webhook payloads (mocked)
- frontend/ - React admin to view orders and download generated PDFs
- Carrier modules are mocked. Replace with real UPS/USPS API code where indicated.

## How to run locally (recommended)
1. Install MongoDB and run it locally.
2. Start backend:
   ```
   cd backend
   npm install
   npm run dev
   ```
3. Start frontend:
   ```
   cd frontend
   npm install
   npm start
   ```

## Next steps to productionize
- Implement real UPS / USPS API calls in `backend/services/ups.js` and `backend/services/usps.js`
- Implement Shopify fulfillment creation in `backend/controllers/fulfillment.js`
- Add authentication to frontend, rate-limiting, robust queue/retry (Redis + Bull), S3 storage, env secret management.
