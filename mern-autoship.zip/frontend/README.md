# Autoship Frontend (MERN Starter)

Simple React admin to view orders processed by the backend.

## Quick start
1. Install dependencies
   ```
   cd frontend
   npm install
   ```

2. Start dev server
   ```
   npm start
   ```

Make sure backend is running at http://localhost:4000 or set `REACT_APP_API_URL`.
