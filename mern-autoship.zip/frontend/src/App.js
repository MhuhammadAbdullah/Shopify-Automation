import React, { useEffect, useState } from 'react';
import API from './api';

function App(){
  const [orders, setOrders] = useState([]);
  useEffect(()=> {
    API.get('/api/orders').then(res=> setOrders(res.data)).catch(console.error);
  }, []);
  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Autoship - Orders</h1>
      <table border="1" cellPadding="8" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead><tr><th>Order ID</th><th>Customer</th><th>Carrier</th><th>Tracking</th><th>Label</th><th>Packing Slip</th><th>Status</th></tr></thead>
        <tbody>
          {orders.map(o=> (
            <tr key={o._id}>
              <td>{o.shopifyOrderId}</td>
              <td>{o.customerName}</td>
              <td>{o.carrier}</td>
              <td>{o.trackingNumber}</td>
              <td>{o.labelPath ? <a href={`${(process.env.REACT_APP_API_URL||'http://localhost:4000')}${o.labelPath}`} target="_blank" rel="noreferrer">Download</a> : '—'}</td>
              <td>{o.packingSlipPath ? <a href={`${(process.env.REACT_APP_API_URL||'http://localhost:4000')}${o.packingSlipPath}`} target="_blank" rel="noreferrer">Download</a> : '—'}</td>
              <td>{o.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
