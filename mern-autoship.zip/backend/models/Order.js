const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ItemSchema = new Schema({
  sku: String,
  name: String,
  quantity: Number,
  weight: Number
}, { _id: false });

const OrderSchema = new Schema({
  shopifyOrderId: { type: String, required: true, unique: true },
  rawPayload: { type: Object },
  customerName: String,
  shippingAddress: Object,
  carrier: String,
  trackingNumber: String,
  labelPath: String,
  packingSlipPath: String,
  status: { type: String, default: 'pending' }, // pending, processed, failed, manual_review
  error: Object,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', OrderSchema);
