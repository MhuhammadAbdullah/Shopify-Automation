function isHawaii(address) {
  if (!address) return false;
  const state = (address.province || address.state || '').toString().toUpperCase();
  const zip = (address.zip || address.postcode || address.postal_code || '').toString();
  if (state === 'HI') return true;
  if (zip.startsWith('967') || zip.startsWith('968')) return true;
  // Honolulu specific (optional)
  if ((address.city || '').toUpperCase().includes('HONOLULU')) return true;
  return false;
}

function selectCarrier(address) {
  return isHawaii(address) ? 'USPS' : 'UPS';
}

module.exports = { isHawaii, selectCarrier };
