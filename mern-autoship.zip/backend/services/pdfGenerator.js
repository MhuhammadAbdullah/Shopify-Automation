const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

function generatePackingSlip(order, outPath) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 40 });
    const stream = fs.createWriteStream(outPath);
    doc.pipe(stream);

    doc.fontSize(20).text('Packing Slip', { align: 'center' });
    doc.moveDown();
    doc.fontSize(12).text(`Order ID: ${order.shopifyOrderId}`);
    doc.text(`Customer: ${order.customerName}`);
    doc.text('Shipping Address:');
    const a = order.shippingAddress || {};
    doc.text(`${a.address1 || ''} ${a.address2 || ''}`);
    doc.text(`${a.city || ''}, ${a.province || ''} ${a.zip || a.postcode || ''}`);
    doc.moveDown();

    doc.text('Items:');
    if (order.rawPayload && order.rawPayload.line_items) {
      order.rawPayload.line_items.forEach(item => {
        doc.text(`${item.quantity} x ${item.title} (SKU: ${item.sku || ''})`);
      });
    }

    doc.end();
    stream.on('finish', ()=> resolve(outPath));
    stream.on('error', (e)=> reject(e));
  });
}

function saveMockLabel(order, outPath) {
  // For MVP we create a simple PDF label (mock). Replace with real carrier label binary.
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: [288, 432], margin: 10 }); // small label
    const stream = fs.createWriteStream(outPath);
    doc.pipe(stream);
    doc.fontSize(10).text('AUTO-SHIP MOCK LABEL', { align: 'center' });
    doc.moveDown();
    doc.text(`Order: ${order.shopifyOrderId}`);
    doc.text(`Carrier: ${order.carrier}`);
    doc.text(`Tracking: ${order.trackingNumber || 'TBD'}`);
    doc.end();
    stream.on('finish', ()=> resolve(outPath));
    stream.on('error', (e)=> reject(e));
  });
}

module.exports = { generatePackingSlip, saveMockLabel };
