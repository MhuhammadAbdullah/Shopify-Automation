# Autoship Backend (MERN Starter) - README

## Overview
This Node/Express backend receives Shopify webhooks (order-paid), selects carrier (UPS or USPS) using Hawaii detection rules, creates a mock shipment, generates a mock label and packing slip PDF, stores them in `/storage`, and updates DB records.

**Important:** Carrier modules (`services/ups.js` and `services/usps.js`) are mocked. Replace with real API calls.

## Quick start (local)
1. Install dependencies:
   ```
   cd backend
   npm install
   ```

2. Environment variables (create a `.env` file in `backend`):
   ```
   PORT=4000
   MONGO_URI=mongodb://localhost:27017/autoship
   SHOPIFY_WEBHOOK_SECRET=your_shopify_webhook_secret_optional
   SHOPIFY_SHOP=your-shop.myshopify.com
   SHOPIFY_ACCESS_TOKEN=your_admin_token
   UPS_API_KEY=...
   USPS_USER=...
   ```

3. Start server:
   ```
   npm run dev
   ```

4. Test webhook (example using curl):
   ```
   curl -X POST http://localhost:4000/webhook/order-paid -H "Content-Type: application/json" -d @sample_order.json
   ```

Generated files will be saved under `backend/storage/` and exposed at `http://localhost:4000/storage/filename.pdf`.
