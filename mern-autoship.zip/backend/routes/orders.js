const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

router.get('/', async (req, res) => {
  const orders = await Order.find().sort({ createdAt: -1 }).limit(200);
  res.json(orders);
});

router.get('/:id', async (req, res) => {
  const o = await Order.findOne({ shopifyOrderId: req.params.id });
  if (!o) return res.status(404).json({ error: 'Not found' });
  res.json(o);
});

module.exports = router;
