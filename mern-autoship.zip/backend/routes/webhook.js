const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const Order = require('../models/Order');
const { selectCarrier } = require('../services/carrierSelector');
const ups = require('../services/ups');
const usps = require('../services/usps');
const { generatePackingSlip, saveMockLabel } = require('../services/pdfGenerator');
const { createShopifyFulfillment } = require('../controllers/fulfillment');
const path = require('path');
const fs = require('fs');

function verifyShopifyWebhook(req) {
  const secret = process.env.SHOPIFY_WEBHOOK_SECRET || '';
  if (!secret) return true; // skip verification if not set (for local dev)
  const hmac = req.get('X-Shopify-Hmac-Sha256') || '';
  const digest = crypto.createHmac('sha256', secret).update(JSON.stringify(req.body)).digest('base64');
  return crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(digest));
}

router.post('/order-paid', async (req, res) => {
  try {
    if (!verifyShopifyWebhook(req)) {
      return res.status(401).send('Webhook verification failed');
    }
    const payload = req.body;
    const shopifyOrderId = String(payload.id || payload.order_id || Date.now());
    // Idempotency: check existing
    let order = await Order.findOne({ shopifyOrderId });
    if (order && (order.status === 'processed' || order.status === 'pending')) {
      return res.json({ ok: true, message: 'Already processed or pending' });
    }
    if (!order) {
      order = new Order({ shopifyOrderId, rawPayload: payload });
    } else {
      order.rawPayload = payload;
    }

    // extract shipping address & name
    const shipping = payload.shipping_address || payload.shipping || payload.customer && payload.customer.default_address || payload.billing_address || {};
    const name = (shipping.name) || (payload.customer && payload.customer.first_name ? payload.customer.first_name + ' ' + payload.customer.last_name : 'Unknown');

    order.customerName = name;
    order.shippingAddress = shipping;

    // select carrier
    const carrier = selectCarrier(shipping);
    order.carrier = carrier;
    order.status = 'processing';
    await order.save();

    // Choose carrier module
    let carrierResult;
    if (carrier === 'USPS') carrierResult = await usps.createShipment(order);
    else carrierResult = await ups.createShipment(order);

    if (!carrierResult || !carrierResult.success) {
      order.status = 'manual_review';
      order.error = carrierResult || { message: 'Carrier error' };
      await order.save();
      return res.status(500).json({ ok: false, error: 'Carrier error', details: carrierResult });
    }

    order.trackingNumber = carrierResult.trackingNumber || ('T' + Date.now());
    // generate label (mock) and packing slip
    const labelPath = path.join(__dirname, '..', 'storage', `${order.shopifyOrderId}-label.pdf`);
    const slipPath = path.join(__dirname, '..', 'storage', `${order.shopifyOrderId}-packing.pdf`);
    await saveMockLabel(order, labelPath);
    await generatePackingSlip(order, slipPath);

    // update paths (exposed via /storage)
    order.labelPath = `/storage/${path.basename(labelPath)}`;
    order.packingSlipPath = `/storage/${path.basename(slipPath)}`;

    // create fulfillment (mock)
    const ful = await createShopifyFulfillment(order, order.trackingNumber, carrierResult.carrier || carrier);
    if (!ful || !ful.success) {
      order.status = 'manual_review';
      order.error = { message: 'Fulfillment failed', ful };
      await order.save();
      return res.status(500).json({ ok: false, error: 'Fulfillment failed' });
    }

    order.status = 'processed';
    await order.save();

    res.json({ ok: true, orderId: order.shopifyOrderId, tracking: order.trackingNumber, label: order.labelPath });
  } catch (e) {
    console.error('Webhook error', e);
    res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
