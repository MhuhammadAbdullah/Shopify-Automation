require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const webhookRoutes = require('./routes/webhook');
const ordersRoutes = require('./routes/orders');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '5mb' }));

// Connect MongoDB
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/autoship';
mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('Mongo connected'))
  .catch(err => console.error('Mongo error', err));

app.use('/webhook', webhookRoutes);
app.use('/api/orders', ordersRoutes);

// Serve stored files
app.use('/storage', express.static(path.join(__dirname, 'storage')));

const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));
