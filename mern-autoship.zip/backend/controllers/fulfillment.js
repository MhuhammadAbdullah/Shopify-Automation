/**
 * Placeholder for Shopify fulfillment creation.
 * To integrate, implement `createShopifyFulfillment(order, trackingNumber, carrier)` using Shopify Admin API.
 * Save credentials in env: SHOPIFY_SHOP, SHOPIFY_ACCESS_TOKEN
 */

const axios = require('axios');

async function createShopifyFulfillment(order, trackingNumber, carrier) {
  // This function currently mocks the behavior. Replace with real API call.
  // Example: POST /admin/api/2025-01/orders/{order_id}/fulfillments.json
  console.log('Mock createShopifyFulfillment', order.shopifyOrderId, trackingNumber, carrier);
  return { success: true };
}

module.exports = { createShopifyFulfillment };
